package com.example.client.wynncalc;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

/**
 * Parses a Wynncraft mount item (e.g. "Wyvern Reins") by reading its custom name and
 * lore lines and extracting the mount level plus current/limit/max for all 8 stats.
 */
public final class LoreParser {

    /** Item name substrings that trigger the calculator. Mutable so more can be added later. */
    public static final Set<String> SUPPORTED_ITEM_NAMES = new HashSet<>();

    static {
        SUPPORTED_ITEM_NAMES.add("Wyvern Reins");
        // Add more here later, e.g. SUPPORTED_ITEM_NAMES.add("Courser Reins");
    }

    /** "Speed  18/40 (57)" — tolerates arbitrary whitespace between parts. */
    private static final Pattern STAT_LINE =
        Pattern.compile("^\\s*([A-Za-z]+)\\s+(\\d+)\\s*/\\s*(\\d+)\\s*\\(\\s*(\\d+)\\s*\\)\\s*$");

    private LoreParser() {}

    /** Returns null if the stack isn't a supported mount item or we couldn't parse it. */
    public static MountStats parse(class_1799 stack) {
        if (stack == null || stack.method_7960()) return null;
        if (!isSupportedItem(stack)) return null;

        class_9290 lore = stack.method_58694(class_9334.field_49632);
        if (lore == null) return null;
        List<class_2561> lines = lore.comp_2400();
        if (lines == null || lines.isEmpty()) return null;

        int[] current = new int[StatType.COUNT];
        int[] limit   = new int[StatType.COUNT];
        int[] max     = new int[StatType.COUNT];
        boolean[] seen = new boolean[StatType.COUNT];

        for (class_2561 line : lines) {
            String clean = sanitize(line.getString());
            if (clean.isEmpty()) continue;

            Matcher sm = STAT_LINE.matcher(clean);
            if (sm.matches()) {
                StatType t = StatType.byDisplayName(sm.group(1));
                if (t != null) {
                    try {
                        int cur = Integer.parseInt(sm.group(2));
                        int lim = Integer.parseInt(sm.group(3));
                        int mx  = Integer.parseInt(sm.group(4));
                        int i = t.ordinal();
                        current[i] = cur;
                        limit[i]   = lim;
                        max[i]     = mx;
                        seen[i]    = true;
                    } catch (NumberFormatException ignored) {}
                }
            }
        }

        // Need all 8 stats — if we got partial, something's off with the item or format.
        for (boolean b : seen) {
            if (!b) return null;
        }

        // Mount's effective level = highest current stat value (the first number in each stat line).
        // This is what picks the ingredient tier.
        int level = 1;
        for (int cur : current) {
            if (cur > level) level = cur;
        }
        return new MountStats(level, current, limit, max);
    }

    private static boolean isSupportedItem(class_1799 stack) {
        String name = stack.method_7964().getString();
        if (name == null || name.isEmpty()) return false;
        for (String needle : SUPPORTED_ITEM_NAMES) {
            if (name.contains(needle)) return true;
        }
        return false;
    }

    /**
     * Strip non-ASCII (Wynncraft uses unicode icons like hearts/check marks)
     * and collapse whitespace — what remains should be matchable with the regex above.
     */
    private static String sanitize(String s) {
        if (s == null) return "";
        // Drop anything outside basic ASCII (section codes, heart symbols, check marks, etc.)
        String ascii = s.replaceAll("[^\\x20-\\x7E]", " ");
        return ascii.replaceAll("\\s+", " ").trim();
    }
}
