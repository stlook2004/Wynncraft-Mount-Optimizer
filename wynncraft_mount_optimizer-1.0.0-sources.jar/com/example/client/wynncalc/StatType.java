package com.example.client.wynncalc;

/**
 * The 8 mount stats for Wynncraft wyvern-type mounts.
 * Declared order matches how they should be displayed in the UI
 * and also matches how stats are listed in the in-game tooltip.
 */
public enum StatType {
    SPD("Speed", "SPD"),
    ACC("Acceleration", "ACC"),
    ALT("Altitude", "ALT"),
    ENG("Energy", "ENG"),
    HND("Handling", "HND"),
    TGH("Toughness", "TGH"),
    BST("Boost", "BST"),
    TNG("Training", "TNG");

    public final String displayName;
    public final String abbrev;

    StatType(String displayName, String abbrev) {
        this.displayName = displayName;
        this.abbrev = abbrev;
    }

    public static StatType byDisplayName(String name) {
        if (name == null) return null;
        for (StatType t : values()) {
            if (t.displayName.equalsIgnoreCase(name)) return t;
        }
        return null;
    }

    public static final int COUNT = values().length;
}
