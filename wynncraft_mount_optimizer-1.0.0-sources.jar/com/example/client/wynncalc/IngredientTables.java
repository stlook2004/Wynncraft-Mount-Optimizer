package com.example.client.wynncalc;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import static com.example.client.wynncalc.StatType.*;

/**
 * Static tables of breeding ingredients for each mount level tier.
 * For a given level L, the applicable list is the highest tier with threshold &lt;= L.
 */
public final class IngredientTables {

    private static final TreeMap<Integer, List<Ingredient>> TABLES = new TreeMap<>();

    static {
        TABLES.put(1, List.of(
            Ingredient.of("Copper Ingot",  ENG, 4, TGH, 8),
            Ingredient.of("Copper Gem",    SPD, 4, ENG, 2, TNG, 6),
            Ingredient.of("Oak Wood",      SPD, 2, ACC, 6, TGH, 4),
            Ingredient.of("Oak Paper",     ALT, 8, BST, 4),
            Ingredient.of("Wheat String",  ACC, 2, HND, 4, BST, 6),
            Ingredient.of("Wheat Grains",  SPD, 8, ALT, 4),
            Ingredient.of("Gudgeon Oil",   ALT, 2, HND, 6, TNG, 4),
            Ingredient.of("Gudgeon Meat",  ACC, 4, ENG, 8)
        ));

        TABLES.put(10, List.of(
            Ingredient.of("Granite Ingot", ENG, 5, TGH, 10),
            Ingredient.of("Granite Gem",   SPD, 5, ENG, 2, TNG, 8),
            Ingredient.of("Birch Wood",    SPD, 2, ACC, 8, TGH, 5),
            Ingredient.of("Birch Paper",   ALT, 10, BST, 5),
            Ingredient.of("Barley String", ACC, 2, HND, 5, BST, 8),
            Ingredient.of("Barley Grains", SPD, 10, ALT, 5),
            Ingredient.of("Trout Oil",     ALT, 2, HND, 8, TNG, 5),
            Ingredient.of("Trout Meat",    ACC, 5, ENG, 10)
        ));

        TABLES.put(20, List.of(
            Ingredient.of("Gold Ingot",    ENG, 5, TGH, 12),
            Ingredient.of("Gold Gem",      SPD, 6, ENG, 3, TNG, 9),
            Ingredient.of("Willow Wood",   SPD, 3, ACC, 9, TGH, 6),
            Ingredient.of("Willow Paper",  ALT, 12, BST, 5),
            Ingredient.of("Oat String",    ACC, 3, HND, 6, BST, 9),
            Ingredient.of("Oat Grains",    SPD, 12, ALT, 5),
            Ingredient.of("Salmon Oil",    ALT, 3, HND, 9, TNG, 6),
            Ingredient.of("Salmon Meat",   ACC, 5, ENG, 12)
        ));

        TABLES.put(30, List.of(
            Ingredient.of("Sandstone Ingot", ENG, 6, TGH, 14),
            Ingredient.of("Sandstone Gem",   SPD, 6, ENG, 3, TNG, 11),
            Ingredient.of("Acacia Wood",     SPD, 3, ACC, 11, TGH, 6),
            Ingredient.of("Acacia Paper",    ALT, 14, BST, 6),
            Ingredient.of("Malt String",     ACC, 3, HND, 6, BST, 11),
            Ingredient.of("Malt Grains",     SPD, 14, ALT, 6),
            Ingredient.of("Carp Oil",        ALT, 3, HND, 11, TNG, 6),
            Ingredient.of("Carp Meat",       ACC, 6, ENG, 14)
        ));

        TABLES.put(40, List.of(
            Ingredient.of("Iron Ingot",    ENG, 6, TGH, 16),
            Ingredient.of("Iron Gem",      SPD, 7, ENG, 3, TNG, 12),
            Ingredient.of("Spruce Wood",   SPD, 3, ACC, 12, TGH, 7),
            Ingredient.of("Spruce Paper",  ALT, 16, BST, 6),
            Ingredient.of("Hops String",   ACC, 3, HND, 7, BST, 12),
            Ingredient.of("Hops Grains",   SPD, 16, ALT, 6),
            Ingredient.of("Icefish Oil",   ALT, 3, HND, 12, TNG, 7),
            Ingredient.of("Icefish Meat",  ACC, 6, ENG, 16)
        ));

        TABLES.put(50, List.of(
            Ingredient.of("Silver Ingot",  ENG, 7, TGH, 18),
            Ingredient.of("Silver Gem",    SPD, 8, ENG, 4, TNG, 14),
            Ingredient.of("Jungle Wood",   SPD, 4, ACC, 14, TGH, 8),
            Ingredient.of("Jungle Paper",  ALT, 18, BST, 7),
            Ingredient.of("Rye String",    ACC, 4, HND, 8, BST, 14),
            Ingredient.of("Rye Grains",    SPD, 18, ALT, 7),
            Ingredient.of("Piranha Oil",   ALT, 4, HND, 14, TNG, 8),
            Ingredient.of("Piranha Meat",  ACC, 7, ENG, 18)
        ));

        TABLES.put(60, List.of(
            Ingredient.of("Cobalt Ingot",  ENG, 8, TGH, 20),
            Ingredient.of("Cobalt Gem",    SPD, 9, ENG, 4, TNG, 15),
            Ingredient.of("Dark Wood",     SPD, 4, ACC, 15, TGH, 9),
            Ingredient.of("Dark Paper",    ALT, 20, BST, 8),
            Ingredient.of("Millet String", ACC, 4, HND, 9, BST, 15),
            Ingredient.of("Millet Grains", SPD, 20, ALT, 8),
            Ingredient.of("Koi Oil",       ALT, 4, HND, 15, TNG, 9),
            Ingredient.of("Koi Meat",      ACC, 8, ENG, 20)
        ));

        TABLES.put(70, List.of(
            Ingredient.of("Kanderstone Ingot", ENG, 8, TGH, 22),
            Ingredient.of("Kanderstone Gem",   SPD, 10, ENG, 4, TNG, 17),
            Ingredient.of("Light Wood",        SPD, 4, ACC, 17, TGH, 10),
            Ingredient.of("Light Paper",       ALT, 22, BST, 8),
            Ingredient.of("Decay String",      ACC, 4, HND, 10, BST, 17),
            Ingredient.of("Decay Grains",      SPD, 22, ALT, 8),
            Ingredient.of("Gylia Oil",         ALT, 4, HND, 17, TNG, 10),
            Ingredient.of("Gylia Meat",        ACC, 8, ENG, 22)
        ));

        TABLES.put(80, List.of(
            Ingredient.of("Diamond Ingot", ENG, 9, TGH, 24),
            Ingredient.of("Diamond Gem",   SPD, 10, ENG, 4, TNG, 18),
            Ingredient.of("Pine Wood",     SPD, 4, ACC, 18, TGH, 10),
            Ingredient.of("Pine Paper",    ALT, 24, BST, 9),
            Ingredient.of("Rice String",   ACC, 4, HND, 10, BST, 18),
            Ingredient.of("Rice Grains",   SPD, 24, ALT, 9),
            Ingredient.of("Bass Oil",      ALT, 4, HND, 18, TNG, 10),
            Ingredient.of("Bass Meat",     ACC, 9, ENG, 24)
        ));

        TABLES.put(90, List.of(
            Ingredient.of("Molten Ingot",    ENG, 9, TGH, 20),
            Ingredient.of("Molten Gem",      SPD, 11, ENG, 5, TNG, 20),
            Ingredient.of("Avo Wood",        SPD, 5, ACC, 20, TGH, 11),
            Ingredient.of("Avo Paper",       ALT, 26, BST, 9),
            Ingredient.of("Sorghum String",  ACC, 5, HND, 11, BST, 20),
            Ingredient.of("Sorghum Grains",  SPD, 26, ALT, 9),
            Ingredient.of("Molten Oil",      ALT, 5, HND, 20, TNG, 11),
            Ingredient.of("Molten Meat",     ACC, 9, ENG, 26)
        ));

        TABLES.put(100, List.of(
            Ingredient.of("Voidstone Ingot", ENG, 10, TGH, 28),
            Ingredient.of("Voidstone Gem",   SPD, 12, ENG, 5, TNG, 21),
            Ingredient.of("Sky Wood",        SPD, 5, ACC, 21, TGH, 12),
            Ingredient.of("Sky Paper",       ALT, 28, BST, 10),
            Ingredient.of("Hemp String",     ACC, 5, HND, 12, BST, 21),
            Ingredient.of("Hemp Grains",     SPD, 28, ALT, 10),
            Ingredient.of("Starfish Oil",    ALT, 5, HND, 21, TNG, 12),
            Ingredient.of("Starfish Meat",   ACC, 10, ENG, 28)
        ));

        TABLES.put(105, List.of(
            Ingredient.of("Dernic Ingot",  ENG, 10, TGH, 29),
            Ingredient.of("Dernic Gem",    SPD, 12, ENG, 5, TNG, 22),
            Ingredient.of("Dernic Wood",   SPD, 5, ACC, 22, TGH, 12),
            Ingredient.of("Dernic Paper",  ALT, 29, BST, 10),
            Ingredient.of("Dernic String", ACC, 5, HND, 12, BST, 22),
            Ingredient.of("Dernic Grains", SPD, 29, ALT, 10),
            Ingredient.of("Dernic Oil",    ALT, 5, HND, 22, TNG, 12),
            Ingredient.of("Dernic Meat",   ACC, 10, ENG, 29)
        ));

        TABLES.put(110, List.of(
            Ingredient.of("Titanium Ingot", ENG, 11, TGH, 30),
            Ingredient.of("Titanium Gem",   SPD, 13, ENG, 5, TNG, 23),
            Ingredient.of("Maple Wood",     SPD, 5, ACC, 23, TGH, 13),
            Ingredient.of("Maple Paper",    ALT, 30, BST, 11),
            Ingredient.of("Jute String",    ACC, 5, HND, 13, BST, 23),
            Ingredient.of("Jute Grains",    SPD, 30, ALT, 11),
            Ingredient.of("Sturgeon Oil",   ALT, 5, HND, 23, TNG, 13),
            Ingredient.of("Sturgeon Meat",  ACC, 11, ENG, 30)
        ));

        TABLES.put(115, List.of(
            Ingredient.of("Cinnabar Ingot",  ENG, 11, TGH, 31),
            Ingredient.of("Cinnabar Gem",    SPD, 13, ENG, 5, TNG, 23),
            Ingredient.of("Redwood Wood",    SPD, 5, ACC, 23, TGH, 13),
            Ingredient.of("Redwood Paper",   ALT, 31, BST, 11),
            Ingredient.of("Heather String",  ACC, 5, HND, 13, BST, 23),
            Ingredient.of("Heather Grains",  SPD, 31, ALT, 11),
            Ingredient.of("Mahseer Oil",     ALT, 5, HND, 23, TNG, 13),
            Ingredient.of("Mahseer Meat",    ACC, 11, ENG, 31)
        ));
    }

    /** Ingredient list that applies at the given mount level. */
    public static List<Ingredient> forLevel(int level) {
        Map.Entry<Integer, List<Ingredient>> e = TABLES.floorEntry(level);
        return e != null ? e.getValue() : TABLES.firstEntry().getValue();
    }

    /** Tier threshold (e.g. 80) used for a level (e.g. 84). */
    public static int tierForLevel(int level) {
        Map.Entry<Integer, List<Ingredient>> e = TABLES.floorEntry(level);
        return e != null ? e.getKey() : TABLES.firstKey();
    }

    private IngredientTables() {}
}
