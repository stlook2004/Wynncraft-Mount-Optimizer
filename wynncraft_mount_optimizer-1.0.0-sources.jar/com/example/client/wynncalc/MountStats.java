package com.example.client.wynncalc;

/**
 * Parsed state of a wyvern-type mount item.
 * All int[] arrays are indexed by {@link StatType#ordinal()} and have length {@link StatType#COUNT}.
 */
public final class MountStats {
    public final int level;
    public final int[] current;
    public final int[] limit;
    public final int[] max;

    public MountStats(int level, int[] current, int[] limit, int[] max) {
        this.level = level;
        this.current = current;
        this.limit = limit;
        this.max = max;
    }

    /** Per-stat gap between current limit and max limit — the amount we need to feed to raise each stat. */
    public int[] targetDeltas() {
        int[] d = new int[StatType.COUNT];
        for (int i = 0; i < d.length; i++) {
            d[i] = Math.max(0, max[i] - limit[i]);
        }
        return d;
    }
}
