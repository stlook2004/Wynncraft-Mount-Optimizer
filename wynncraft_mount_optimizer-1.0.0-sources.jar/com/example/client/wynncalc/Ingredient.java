package com.example.client.wynncalc;

/**
 * A single breeding ingredient — a named item with stat contributions indexed by StatType.ordinal().
 */
public final class Ingredient {
    public final String name;
    public final int[] values;

    private Ingredient(String name, int[] values) {
        this.name = name;
        this.values = values;
    }

    /**
     * Convenience constructor.
     * Pairs alternate between StatType and int value:
     *   Ingredient.of("Copper Ingot", ENG, 4, TGH, 8)
     */
    public static Ingredient of(String name, Object... pairs) {
        int[] v = new int[StatType.COUNT];
        if ((pairs.length & 1) != 0) {
            throw new IllegalArgumentException("Ingredient.of requires pairs of (StatType, int)");
        }
        for (int i = 0; i < pairs.length; i += 2) {
            StatType t = (StatType) pairs[i];
            int val = ((Number) pairs[i + 1]).intValue();
            v[t.ordinal()] = val;
        }
        return new Ingredient(name, v);
    }

    public int value(StatType t) {
        return values[t.ordinal()];
    }

    public int totalValue() {
        int s = 0;
        for (int v : values) s += v;
        return s;
    }
}
