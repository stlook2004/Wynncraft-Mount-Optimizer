package com.example.client.wynncalc;

import java.util.ArrayList;
import java.util.List;

/**
 * Branch-and-bound integer programming solver for the mount-breeding problem.
 *
 * Given targets[] (how much each stat needs to gain) and a list of ingredients with
 * per-stat contributions, find a non-negative integer count vector that minimizes
 * the total number of ingredients used subject to covering every target stat.
 *
 * Problem size is small (&le; 8 ingredients, &le; 8 stats, targets bounded by ~40),
 * so a bounded recursion with a greedy warm-start is more than fast enough for
 * tooltip-time evaluation.
 */
public final class Solver {

    /** Result wrapper — parallel to the ingredient list passed in. */
    public static final class Result {
        public final int[] counts;            // parallel to ingredients
        public final int total;               // sum(counts)
        public final int[] finalCoverage;     // actual stat totals achieved
        public final int[] remainingDeficit;  // max(0, target - coverage); should be all zero on success

        public Result(int[] counts, int total, int[] finalCoverage, int[] remainingDeficit) {
            this.counts = counts;
            this.total = total;
            this.finalCoverage = finalCoverage;
            this.remainingDeficit = remainingDeficit;
        }

        public boolean fullyCovers() {
            for (int v : remainingDeficit) if (v > 0) return false;
            return true;
        }
    }

    /** Expanded result line that keeps the name of each used ingredient. */
    public static final class Line {
        public final String name;
        public final int count;
        public Line(String name, int count) { this.name = name; this.count = count; }
    }

    private Solver() {}

    public static Result solve(int[] targets, List<Ingredient> ingredients) {
        int n = ingredients.size();
        int m = targets.length;

        int[] clamped = new int[m];
        for (int s = 0; s < m; s++) clamped[s] = Math.max(0, targets[s]);

        int[][] contrib = new int[n][m];
        for (int i = 0; i < n; i++) contrib[i] = ingredients.get(i).values;

        // Early out — nothing to do.
        if (!hasPositive(clamped)) {
            int[] counts = new int[n];
            int[] cov = new int[m];
            return new Result(counts, 0, cov, new int[m]);
        }

        // Warm-start with a greedy upper bound, so the recursion can prune aggressively.
        int[] greedy = greedy(clamped, contrib);
        int[] best = greedy.clone();
        int bestTotal = sum(greedy);

        int[] counts = new int[n];
        int[] remaining = clamped.clone();
        int[] bestTotalBox = new int[]{bestTotal};
        int[][] bestBox = new int[][]{best};

        // Deadline guard — absurd inputs shouldn't lock the client render thread.
        long deadlineNs = System.nanoTime() + 200_000_000L; // 200ms

        recurse(0, counts, remaining, contrib, 0, bestBox, bestTotalBox, deadlineNs);

        int[] finalCounts = bestBox[0];
        int[] coverage = new int[m];
        for (int i = 0; i < n; i++) {
            int c = finalCounts[i];
            if (c == 0) continue;
            int[] v = contrib[i];
            for (int s = 0; s < m; s++) coverage[s] += c * v[s];
        }
        int[] deficit = new int[m];
        for (int s = 0; s < m; s++) deficit[s] = Math.max(0, clamped[s] - coverage[s]);

        return new Result(finalCounts, bestTotalBox[0], coverage, deficit);
    }

    public static List<Line> expand(Result r, List<Ingredient> ingredients) {
        List<Line> out = new ArrayList<>();
        for (int i = 0; i < ingredients.size(); i++) {
            int c = r.counts[i];
            if (c > 0) out.add(new Line(ingredients.get(i).name, c));
        }
        return out;
    }

    private static void recurse(int i, int[] counts, int[] remaining, int[][] contrib,
                                int total, int[][] bestBox, int[] bestTotalBox, long deadlineNs) {
        if (total >= bestTotalBox[0]) return;

        if (!hasPositive(remaining)) {
            // Found a feasible solution strictly better than bestTotal (guarded above).
            bestBox[0] = counts.clone();
            bestTotalBox[0] = total;
            return;
        }

        if (i == counts.length) return;

        if ((System.nanoTime() - deadlineNs) > 0) return;

        // Upper bound on how many of ingredient i we might reasonably take: just enough to
        // cover any single remaining stat on its own. Going higher can't help.
        int maxCount = 0;
        for (int s = 0; s < remaining.length; s++) {
            if (remaining[s] > 0 && contrib[i][s] > 0) {
                int needed = (remaining[s] + contrib[i][s] - 1) / contrib[i][s];
                if (needed > maxCount) maxCount = needed;
            }
        }
        int cap = bestTotalBox[0] - total - 1; // must strictly improve
        if (cap < maxCount) maxCount = cap;
        if (maxCount < 0) maxCount = 0;

        int[] newRem = new int[remaining.length];
        // Try high-to-low: finds good solutions fast which tightens the bound.
        for (int c = maxCount; c >= 0; c--) {
            counts[i] = c;
            for (int s = 0; s < remaining.length; s++) {
                newRem[s] = remaining[s] - c * contrib[i][s];
            }
            recurse(i + 1, counts, newRem, contrib, total + c, bestBox, bestTotalBox, deadlineNs);
        }
        counts[i] = 0;
    }

    /**
     * Greedy: repeatedly pick the ingredient that covers the most *useful* remaining need
     * (clamped to what's still needed per stat — no credit for overshoot). Gives a valid
     * upper bound and usually an already-good solution.
     */
    private static int[] greedy(int[] remaining, int[][] contrib) {
        int n = contrib.length;
        int[] counts = new int[n];
        int[] rem = remaining.clone();

        // Safety cap in case no ingredient can make any remaining stat progress.
        for (int iter = 0; iter < 1000 && hasPositive(rem); iter++) {
            int bestI = -1;
            int bestScore = 0;
            for (int i = 0; i < n; i++) {
                int score = 0;
                for (int s = 0; s < rem.length; s++) {
                    if (rem[s] > 0) score += Math.min(rem[s], contrib[i][s]);
                }
                if (score > bestScore) { bestScore = score; bestI = i; }
            }
            if (bestI < 0) break;
            counts[bestI]++;
            for (int s = 0; s < rem.length; s++) rem[s] -= contrib[bestI][s];
        }
        return counts;
    }

    private static boolean hasPositive(int[] a) {
        for (int v : a) if (v > 0) return true;
        return false;
    }

    private static int sum(int[] a) {
        int s = 0;
        for (int v : a) s += v;
        return s;
    }
}
