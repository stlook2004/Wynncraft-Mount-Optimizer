package com.example.client.wynncalc;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_437;

/**
 * Renders a tooltip-style side panel next to the vanilla item tooltip showing the
 * optimal breeding ingredient list for a hovered Wyvern Reins (or other supported mount).
 */
public final class CalculatorRenderer {

    private CalculatorRenderer() {}

    // Color palette roughly matching vanilla tooltips but a touch warmer for distinction.
    private static final int BG_COLOR        = 0xF0100010;
    private static final int BORDER_TOP      = 0xFF5028A0;
    private static final int BORDER_BOT      = 0xFF28005F;
    private static final int TITLE_COLOR     = 0xFFFFD244;
    private static final int SUBTITLE_COLOR  = 0xFFAAAAAA;
    private static final int TEXT_COLOR      = 0xFFFFFFFF;
    private static final int COUNT_COLOR     = 0xFF55FF55;
    private static final int ACCENT_COLOR    = 0xFFFFAA00;
    private static final int DIM_COLOR       = 0xFF707070;
    private static final int WARN_COLOR      = 0xFFFF5555;

    private static final int PAD = 5;
    private static final int LINE_H = 10;
    private static final int GAP_FROM_TOOLTIP = 6;

    public static void render(class_332 g, class_1799 stack, int mouseX, int mouseY, int screenWidth, int screenHeight) {
        if (stack == null || stack.method_7960()) return;
        MountStats stats = LoreParser.parse(stack);
        if (stats == null) return;

        List<Ingredient> ingredients = IngredientTables.forLevel(stats.level);
        int tier = IngredientTables.tierForLevel(stats.level);
        int[] targets = stats.targetDeltas();
        Solver.Result result = Solver.solve(targets, ingredients);

        class_310 mc = class_310.method_1551();
        class_327 font = mc.field_1772;

        // Build the lines we're about to draw. Each line is a (component, color) pair.
        List<Row> rows = buildRows(stats, tier, targets, ingredients, result);

        // Panel size
        int contentW = 0;
        for (Row r : rows) contentW = Math.max(contentW, r.width(font));
        int panelW = contentW + PAD * 2;
        int panelH = PAD * 2 + rows.size() * LINE_H;

        // Vanilla tooltip width — we need it to position the panel to the right of the tooltip.
        List<class_2561> tooltipLines = class_437.method_25408(mc, stack);
        int tooltipW = 0;
        for (class_2561 line : tooltipLines) tooltipW = Math.max(tooltipW, font.method_27525(line));
        int tooltipBoxW = tooltipW + 6;   // vanilla draws 3px padding each side

        // Preferred: to the right of the tooltip. Fallback: to the left.
        int panelX = mouseX + 12 + tooltipBoxW + GAP_FROM_TOOLTIP;
        if (panelX + panelW + 4 > screenWidth) {
            int leftX = mouseX - 12 - panelW - GAP_FROM_TOOLTIP;
            panelX = Math.max(4, leftX);
        }
        if (panelX + panelW + 4 > screenWidth) panelX = screenWidth - panelW - 4;
        if (panelX < 4) panelX = 4;

        int panelY = mouseY - 12;
        if (panelY + panelH + 4 > screenHeight) panelY = screenHeight - panelH - 4;
        if (panelY < 4) panelY = 4;

        drawPanelBackground(g, panelX, panelY, panelW, panelH);

        int tx = panelX + PAD;
        int ty = panelY + PAD;
        for (Row r : rows) {
            r.draw(g, font, tx, ty);
            ty += LINE_H;
        }
    }

    private static List<Row> buildRows(MountStats stats, int tier, int[] targets,
                                       List<Ingredient> ingredients, Solver.Result result) {
        List<Row> rows = new ArrayList<>();

        // Header
        rows.add(Row.text("Breeding Calc", TITLE_COLOR)
            .append("  Tier " + tier + "  ", SUBTITLE_COLOR)
            .append("(Lvl " + stats.level + ")", DIM_COLOR));
        rows.add(Row.blank());

        // Targets — in the user-specified abbreviation order.
        rows.add(Row.text("Targets (max \u2212 limit)", SUBTITLE_COLOR));
        boolean anyTarget = false;
        StatType[] order = StatType.values(); // SPD, ACC, ALT, ENG, HND, TGH, BST, TNG
        Row t1 = Row.empty();
        for (int i = 0; i < 4; i++) {
            if (i > 0) t1.append("  ", TEXT_COLOR);
            appendStatEntry(t1, order[i], targets[order[i].ordinal()]);
            if (targets[order[i].ordinal()] > 0) anyTarget = true;
        }
        Row t2 = Row.empty();
        for (int i = 4; i < 8; i++) {
            if (i > 4) t2.append("  ", TEXT_COLOR);
            appendStatEntry(t2, order[i], targets[order[i].ordinal()]);
            if (targets[order[i].ordinal()] > 0) anyTarget = true;
        }
        rows.add(t1);
        rows.add(t2);
        rows.add(Row.blank());

        // Ingredient list
        if (!anyTarget) {
            rows.add(Row.text("All stats already maxed!", COUNT_COLOR));
            return rows;
        }

        rows.add(Row.text("Optimal feed:", SUBTITLE_COLOR));
        List<Solver.Line> lines = Solver.expand(result, ingredients);
        if (lines.isEmpty()) {
            rows.add(Row.text("  (no ingredients needed)", TEXT_COLOR));
        } else {
            for (Solver.Line ln : lines) {
                Row r = Row.empty()
                    .append("  " + ln.count + "x ", COUNT_COLOR)
                    .append(ln.name, TEXT_COLOR);
                rows.add(r);
            }
        }

        rows.add(Row.blank());
        rows.add(Row.text("Total: ", SUBTITLE_COLOR)
            .append(String.valueOf(result.total), ACCENT_COLOR)
            .append(" ingredient" + (result.total == 1 ? "" : "s"), SUBTITLE_COLOR));

        if (!result.fullyCovers()) {
            // Should be rare — only if the ingredient set literally can't reach some stat
            // (e.g. user-provided data is incomplete for a tier). Surface it instead of silently shipping a bad answer.
            Row warn = Row.text("Warning: solution is incomplete", WARN_COLOR);
            rows.add(warn);
        }
        return rows;
    }

    private static void appendStatEntry(Row row, StatType t, int value) {
        row.append(t.abbrev + " ", SUBTITLE_COLOR);
        int color = value > 0 ? TEXT_COLOR : DIM_COLOR;
        String txt = value > 0 ? ("+" + value) : "0";
        // Pad to consistent width (3 chars) for column alignment.
        while (txt.length() < 3) txt = " " + txt;
        row.append(txt, color);
    }

    /** Draws the vanilla-tooltip-style background and border. */
    private static void drawPanelBackground(class_332 g, int x, int y, int w, int h) {
        int x1 = x, y1 = y, x2 = x + w, y2 = y + h;
        // Main fill
        g.method_25294(x1, y1, x2, y2, BG_COLOR);
        // Inset border (1px inside each edge)
        int bx1 = x1 + 1, by1 = y1 + 1, bx2 = x2 - 1, by2 = y2 - 1;
        g.method_25294(bx1, by1, bx2, by1 + 1, BORDER_TOP);        // top
        g.method_25294(bx1, by2 - 1, bx2, by2, BORDER_BOT);        // bottom
        g.method_25294(bx1, by1, bx1 + 1, by2, BORDER_TOP);        // left
        g.method_25294(bx2 - 1, by1, bx2, by2, BORDER_BOT);        // right
    }

    // ---------- tiny row builder ----------
    private static final class Row {
        private final List<Segment> segments = new ArrayList<>();

        static Row empty()                          { return new Row(); }
        static Row blank()                          { return new Row(); /* renders as empty line */ }
        static Row text(String s, int color)        { Row r = new Row(); r.append(s, color); return r; }

        Row append(String s, int color) { segments.add(new Segment(s, color)); return this; }

        int width(class_327 font) {
            int w = 0;
            for (Segment s : segments) w += font.method_1727(s.text);
            return w;
        }

        void draw(class_332 g, class_327 font, int x, int y) {
            int cx = x;
            for (Segment s : segments) {
                g.method_51433(font, s.text, cx, y, s.color, true);
                cx += font.method_1727(s.text);
            }
        }

        private static final class Segment {
            final String text;
            final int color;
            Segment(String text, int color) { this.text = text; this.color = color; }
        }
    }
}
