package com.example.client.mixin;

import com.example.client.wynncalc.CalculatorRenderer;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_332;
import net.minecraft.class_465;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Injects at the tail of AbstractContainerScreen#render, AFTER the vanilla tooltip has been drawn.
 * If the hovered slot contains a supported mount item, draws the calculator side-panel.
 */
@Mixin(class_465.class)
public class AbstractContainerScreenMixin {

    @Shadow
    @Nullable
    protected class_1735 hoveredSlot;

    @Inject(method = "render", at = @At("TAIL"))
    private void wynncalc$renderSidePanel(class_332 graphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        class_1735 slot = this.hoveredSlot;
        if (slot == null || !slot.method_7681()) return;
        class_1799 stack = slot.method_7677();

        // width/height are public fields on the Screen superclass in Mojang mappings.
        net.minecraft.class_437 self = (net.minecraft.class_437) (Object) this;
        CalculatorRenderer.render(graphics, stack, mouseX, mouseY, self.field_22789, self.field_22790);
    }
}
